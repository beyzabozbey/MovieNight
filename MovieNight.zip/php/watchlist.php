<?php

	require("connector.php");
	
	$email = $_POST['email'];
	
	$qry = "SELECT * FROM watchlist w WHERE w.email = '$email'";
	$mysqli_result = mysqli_query($db, $qry);
	while($row = mysqli_fetch_assoc($mysqli_result)){
		echo $row['title']."\n".$row['description']."\n".$row['movid']."\n".$row['photo']."\n";
	}
	
	mysqli_close($db);
?>