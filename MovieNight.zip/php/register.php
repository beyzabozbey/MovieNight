<?php

//Make the database connection with mysqli_connect function 
//$db = mysqli_connect('localhost', 'root', '', 'movies');
require("connector.php");
//$id = (int)$_POST['idInput'];
$email = $_POST['email'];
$pwd = $_POST['pwd'];
	
	//Prepare the query
	$sql = "SELECT * FROM users u WHERE u.email='$email'";
	
	//Execute and receive the result of the query
	$mysqli_result = mysqli_query($db, $sql);
	
	//Receive the number of rows returned by the query
	$count = mysqli_num_rows($mysqli_result);
	
	if($count==0) {
		
		$sql = "INSERT INTO users (email, pwd, id) VALUES ('$email', '$pwd', NULL)";
		mysqli_query($db, $sql);
		echo "Successfully registered";
	}
	else {
		echo "User already exists";
	}

mysqli_close($db);
?>




