<?php

	require("connector.php");
	
	$email = $_POST['email'];
	$pwd = $_POST['pwd'];
	$mysql_qry = "SELECT * FROM users u WHERE u.email = '$email' AND u.pwd = '$pwd'";
 
	$result = mysqli_query($db, $mysql_qry);
	$count = mysqli_num_rows($result);
	if($count == 0) {
		echo "login not success";
	}else{
		echo "login success !!!";
	}
	
	mysqli_close($db);
?>