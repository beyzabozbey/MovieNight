<?php

	require("connector.php");
	
	$email = $_POST['email'];
	$movid = (int)$_POST['movid'];
	$qry = "SELECT * FROM watchlist w WHERE w.email = '$email' AND w.movid = '$movid'";
	$result = mysqli_query($db, $qry);
	$count = mysqli_num_rows($result);
	if($count > 0)
		echo "delete";
	else
		echo "add";
	
	mysqli_close($db);
?>