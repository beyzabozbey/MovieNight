<?php

	require("connector.php");
	
	$email = $_POST['email'];
	$title = $_POST['title'];
	$movid = (int)$_POST['movid'];
	$desc = $_POST['description'];
	$photo = $_POST['photo'];
	$qry = "INSERT INTO watchedlist (email, movid, title, description, photo) VALUES ('$email', '$movid', '$title', '$desc', '$photo')";
	mysqli_query($db, $qry);
	echo "Movie added to Watchedlist";
	
	mysqli_close($db);
?>