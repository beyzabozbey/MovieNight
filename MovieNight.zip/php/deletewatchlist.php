<?php

	require("connector.php");
	
	$email = $_POST['email'];
	$movid = (int)$_POST['movid'];
	$qry = "DELETE FROM `watchlist` WHERE `email` = '$email' AND `movid` = $movid";
	mysqli_query($db, $qry);
	echo "Movie deleted from Watchlist";
	
	mysqli_close($db);
?>