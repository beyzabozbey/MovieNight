<?php

	require("connector.php");
	
	$email = $_POST['email'];
	$movid = (int)$_POST['movid'];
	$qry = "DELETE FROM `watchedlist` WHERE `email` = '$email' AND `movid` = $movid";
	mysqli_query($db, $qry);
	echo "Movie deleted from Watchedlist";
	
	mysqli_close($db);
?>