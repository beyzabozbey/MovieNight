package com.cs310.sp2016.movienight;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class MoviePageActivity extends BaseActivity {
    public static final String EXTRA_MESSAGE = "message";
    public static final String EXTRA_EMAIL = "message2";
    //Button button;
    ImageView imageView;
    TextView textTitle;
    TextView textDesc;
    //DBHelper dbHelper = new DBHelper(this);
    Movies movie;
    String email;
    Button button2;
    ProgressDialog prgDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_page);
        System.out.println("MoviePageActivity la la la ");
        Intent i = getIntent();
        email = i.getStringExtra(EXTRA_EMAIL);
        System.out.println("*********** " + email );
        String moviename = i.getStringExtra(EXTRA_MESSAGE);
        String mdesc = i.getStringExtra("moviedesc");
        int m_id = Integer.parseInt(i.getStringExtra("movieid"));
        String ppath = i.getStringExtra("movieposter");
        movie = new Movies();
        movie.setName(moviename);
        movie.setDescription(mdesc);
        movie.setPoster_path(ppath);
        movie.setId(m_id);
        System.out.println("blalba*********** " + moviename + " " + mdesc + " " + m_id + " " + ppath);
        //movie.setBitmap((Bitmap) i.getParcelableExtra("moviephoto"));
        System.out.println("hahaha*********** " + movie.getPoster_path());

        imageView= (ImageView)findViewById(R.id.imageView);
        textTitle = (TextView)findViewById(R.id.textTitle);
        textDesc = (TextView)findViewById(R.id.textDesc);
        //button = (Button)findViewById(R.id.button);

        Task tsk = new Task();
        tsk.execute();
    }

    public void onButton(View v){
        AddMovies tsk = new AddMovies();
        tsk.execute("watchlist");
    }

    public void onButton2(View v){
        AddMovies tsk = new AddMovies();
        tsk.execute("watchedlist");
    }

    class Task extends AsyncTask<String, Void, String> {

        @Override
        protected void onPreExecute(){
            prgDialog = new ProgressDialog(MoviePageActivity.this);
            prgDialog.setTitle("Loading");
            prgDialog.setMessage("Please wait...");
            prgDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            prgDialog.show();
        }
        @Override
        protected String doInBackground(String... params){
            StringBuilder imageUrl = new StringBuilder();
            imageUrl.append("http://image.tmdb.org/t/p/w300/" + movie.getPoster_path());
            Bitmap bitmap = null;
            try{
                InputStream is = new URL(imageUrl.toString()).openStream();
                bitmap = BitmapFactory.decodeStream(is);
            }catch(Exception e){
                e.printStackTrace();
            }
            movie.setBitmap(bitmap);
            return null;
        }

        @Override
        protected void onPostExecute(String result){
            imageView.setImageBitmap(movie.getBitmap());
            textTitle.setText(movie.getName());
            textDesc.setText(movie.getDescription());
            prgDialog.dismiss();
        }


    }

    public class AddMovies extends AsyncTask<String, Void, String> {
        String maintype = "";
        String action="";
        @Override
        protected void onPreExecute() {
            prgDialog = new ProgressDialog(MoviePageActivity.this);
            prgDialog.setTitle("Loading");
            prgDialog.setMessage("Please wait...");
            prgDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            prgDialog.show();
        }

        @Override
        protected String doInBackground(String... params) {
            maintype = params[0];
            action = checkList();
            StringBuilder IP = new StringBuilder("http://192.168.1.48");
            if(maintype.equals("watchlist") && action.equals("add"))
                IP.append("/MovieNight/addwatchlist.php");
            else if(maintype.equals("watchlist") && action.equals("delete"))
                IP.append("/MovieNight/deletewatchlist.php");
            else if(maintype.equals("watchedlist") && action.equals("add"))
                IP.append("/MovieNight/addwatchedlist.php");
            else
                IP.append("/MovieNight/deletewatchedlist.php");
            String Url = IP.toString();
            System.out.println("URLLLLL " + Url);
            try {
                URL url = new URL(Url);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);
                connection.setDoInput(true);
                OutputStream outputStream = connection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data;
                if(action.equals("add")) {
                    post_data = URLEncoder.encode("email", "UTF-8") + "=" + URLEncoder.encode(email, "UTF-8") + "&" +
                            URLEncoder.encode("movid", "UTF-8") + "=" + URLEncoder.encode(String.valueOf(movie.getId()), "UTF-8") + "&" +
                            URLEncoder.encode("title", "UTF-8") + "=" + URLEncoder.encode(movie.getName(), "UTF-8") + "&" +
                            URLEncoder.encode("description", "UTF-8") + "=" + URLEncoder.encode(movie.getDescription(), "UTF-8") + "&" +
                            URLEncoder.encode("photo", "UTF-8") + "=" + URLEncoder.encode(movie.getPoster_path(), "UTF-8");
                }
                else {
                    post_data = URLEncoder.encode("email", "UTF-8") + "=" + URLEncoder.encode(email, "UTF-8") + "&" +
                            URLEncoder.encode("movid", "UTF-8") + "=" + URLEncoder.encode(String.valueOf(movie.getId()), "UTF-8");
                }
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = connection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                String result = "";
                String line = "";
                StringBuilder str = new StringBuilder();
                while ((line = bufferedReader.readLine()) != null) {
                    str.append(line);
                }
                result = str.toString();
                bufferedReader.close();
                inputStream.close();
                connection.disconnect();
                return result;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }

        @Override
        protected void onPostExecute(String result) {
            prgDialog.dismiss();
            Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
        }
        private String checkList(){
            StringBuilder IP = new StringBuilder("http://192.168.1.48");
            if(maintype.equals("watchlist"))
                IP.append("/MovieNight/checkwatchlist.php");
            else
                IP.append("/MovieNight/checkwatchedlist.php");
            String Url = IP.toString();
            try {
                URL url = new URL(Url);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);
                connection.setDoInput(true);
                OutputStream outputStream = connection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("email", "UTF-8") + "=" + URLEncoder.encode(email, "UTF-8") + "&" +
                        URLEncoder.encode("movid", "UTF-8") + "=" + URLEncoder.encode(String.valueOf(movie.getId()), "UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                InputStream inputStream = connection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                String result = "";
                String line = "";
                StringBuilder str = new StringBuilder();
                while ((line = bufferedReader.readLine()) != null) {
                    str.append(line);
                }
                result = str.toString();
                bufferedReader.close();
                inputStream.close();
                connection.disconnect();
                return result;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;

        }
    }
}
