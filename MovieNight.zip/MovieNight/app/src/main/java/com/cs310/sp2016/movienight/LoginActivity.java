package com.cs310.sp2016.movienight;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;

public class LoginActivity extends AppCompatActivity {
    public static final String EXTRA_EMAIL = "message";
    public static final String EXTRA_PWD = "password";
    //DBHelper dbHelper = new DBHelper(this);
    ProgressDialog prgDialog;
    //String type = "";
    boolean flag = false;
    String email="", pwd="";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
    }

    public void onLogin(View v){
        TextView tvbtn1 = (TextView)findViewById(R.id.logemail);
        email = tvbtn1.getText().toString();
        TextView tvbtn2 = (TextView)findViewById(R.id.logpwd);
        pwd = tvbtn2.getText().toString();
		if(email.equals("") || pwd.equals(""))
			Toast.makeText(getApplicationContext(), "You have to fill all fields", Toast.LENGTH_SHORT).show();
		else{
			Task tsk = new Task();
			tsk.execute("login", email, pwd);
		}

        /*    Intent i = new Intent(this, MainActivity.class);
            i.putExtra(MainActivity.EXTRA_EMAIL, email);
            i.putExtra(MainActivity.EXTRA_PWD, pwd);
            startActivity(i);
        finish();*/

        /*if(dbHelper.controlUser(email, pwd)) {
            Intent i = new Intent(this, MainActivity.class);
            i.putExtra(EXTRA_EMAIL, email);
            i.putExtra(EXTRA_PWD, pwd);
            startActivity(i);
        }
        else if(dbHelper.getUser(email))
            Toast.makeText(getApplicationContext(), "Password is wrong.", Toast.LENGTH_SHORT).show();
        else
            Toast.makeText(getApplicationContext(), "No user found with email: " + email, Toast.LENGTH_SHORT).show();*/
    }
    public void onRegister(View v){
        TextView tvbtn1 = (TextView)findViewById(R.id.logemail);
        email = tvbtn1.getText().toString();
        TextView tvbtn2 = (TextView)findViewById(R.id.logpwd);
        pwd = tvbtn2.getText().toString();
        System.out.println(email + " " + pwd + " **********");
		if(email.equals("") || pwd.equals(""))
			Toast.makeText(getApplicationContext(), "You have to fill all fields", Toast.LENGTH_SHORT).show();
		else{
			Task tsk = new Task();
			tsk.execute("register", email, pwd);
		}
        /*Intent i = new Intent(getApplicationContext(), MainActivity.class);
        i.putExtra(MainActivity.EXTRA_EMAIL, email);
        i.putExtra(MainActivity.EXTRA_PWD, pwd);
        startActivity(i);
        finish();*/
        /*if(flag){
            Intent i = new Intent(this, MainActivity.class);
            i.putExtra(MainActivity.EXTRA_EMAIL, email);
            i.putExtra(MainActivity.EXTRA_PWD, pwd);
            startActivity(i);
        }*/
        //type = "register";
        /*if(dbHelper.getUser(email))
            Toast.makeText(getApplicationContext(), "Email already exists.", Toast.LENGTH_SHORT).show();
        else{
            dbHelper.insertUser(email, pwd);
            Intent i = new Intent(this, MainActivity.class);
            i.putExtra(EXTRA_EMAIL, email);
            i.putExtra(EXTRA_PWD, pwd);
            startActivity(i);
        }*/
    }

    public class Task extends AsyncTask<String, Void, String>{
        String maintype="";
        @Override
        protected void onPreExecute(){
            prgDialog = new ProgressDialog(LoginActivity.this);
            prgDialog.setTitle("Loading");
            prgDialog.setMessage("Please wait...");
            prgDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            prgDialog.show();
        }
        @Override
        protected String doInBackground(String... params){
            String type = params[0];
            maintype = type;
            if(type.equals("register")){
                return register(params);
            }
            else { //if(type.equals("login")){
                return login(params);
            }
        }
        @Override
        protected void onPostExecute(String result){
            prgDialog.dismiss();
            if(maintype.equals("register")){
                if(result.equals("User already exists")){
                    Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show(); // user already exists
                }
                else{
                    Toast.makeText(getApplicationContext(), "Successfully registered", Toast.LENGTH_SHORT).show();
                    Intent i = new Intent(getApplicationContext(), MainActivity.class);
                    i.putExtra(MainActivity.EXTRA_EMAIL, email);
                    i.putExtra(MainActivity.EXTRA_PWD, pwd);
                    startActivity(i);
                    finish();
                }
            }
            else{
                Toast.makeText(getApplicationContext(), result, Toast.LENGTH_SHORT).show();
                System.out.println(result);
                if(result.equals("login success !!!")){
                    Intent i = new Intent(getApplicationContext(), MainActivity.class);
                    i.putExtra(MainActivity.EXTRA_EMAIL, email);
                    i.putExtra(MainActivity.EXTRA_PWD, pwd);
                    startActivity(i);
                    finish();
                }
               // else
               //     flag = false;
            }
        }

        private String register(String... params) {
            String registerUrl = "http://192.168.1.48/MovieNight/register.php";
            try {
                String email = params[1];
                String pwd = params[2];
                URL url = new URL(registerUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);
                connection.setDoInput(true);
                OutputStream outputStream = connection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("email", "UTF-8") + "=" + URLEncoder.encode(email, "UTF-8") + "&" +
                        URLEncoder.encode("pwd", "UTF-8") + "=" + URLEncoder.encode(pwd, "UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = connection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                String result = "";
                String line = "";
                StringBuilder str = new StringBuilder();
                while ((line = bufferedReader.readLine()) != null) {
                    str.append(line);
                }
                result = str.toString();
                bufferedReader.close();
                inputStream.close();
                connection.disconnect();
                return result;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
        private String login(String... params){
            String loginUrl = "http://192.168.1.48/MovieNight/login.php";
            try {
                String email = params[1];
                String pwd = params[2];
                URL url = new URL(loginUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);
                connection.setDoInput(true);
                OutputStream outputStream = connection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("email", "UTF-8") + "=" + URLEncoder.encode(email, "UTF-8") + "&" +
                        URLEncoder.encode("pwd", "UTF-8") + "=" + URLEncoder.encode(pwd, "UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                InputStream inputStream = connection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                String result = "";
                String line = "";
                StringBuilder str = new StringBuilder();
                while ((line = bufferedReader.readLine()) != null) {
                    str.append(line);
                }
                result = str.toString();
                bufferedReader.close();
                inputStream.close();
                connection.disconnect();
                return result;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }
}
