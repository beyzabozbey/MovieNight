package com.cs310.sp2016.movienight;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends BaseActivity {
    public static final String EXTRA_EMAIL = "message";
    public static final String EXTRA_PWD = "password";
    HashMap<String, String> genres = new HashMap<String, String>();
    List<Button> buttons;
    /*final int[] ButtonIDs = {
            R.id.genre1,
            R.id.genre2,
            R.id.genre3,
            R.id.genre4,
            R.id.genre5,
            R.id.genre6,
            R.id.genre7,
            R.id.genre8,
            R.id.genre9,
            R.id.genre10,
            R.id.genre11,
            R.id.genre12,
    };*/
    String email;
    String pwd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Intent i = getIntent();
        email = i.getStringExtra(EXTRA_EMAIL);
        pwd = i.getStringExtra(EXTRA_PWD);
        /*buttons = new ArrayList<Button>();
        for(int id : ButtonIDs){
            Button button = (Button)findViewById(id);
            buttons.add(button);
        }*/
        setGenres();

    }

    public void setGenres(){
        genres.put("Action","28");
        genres.put("Adventure","12");
        genres.put("Animation","16");
        genres.put("Comedy","35");
        genres.put("Crime","80");
        genres.put("Documentary","99");
        genres.put("Drama","18");
        genres.put("Family", "10751");
        genres.put("Fantasy", "14");
        genres.put("Horror", "27");
        genres.put("Romance", "10749");
        genres.put("Sci_Fi", "878");

    }

    public void onListMovies(View v){
        //Button button =(Button)findViewById(v.getId());
        String genre = v.getResources().getResourceName(v.getId());
        int index = genre.indexOf('/');
        genre = genre.substring(index+1);
        //System.out.println("bla bla " + genre + " ***GENRE***");
        String genreID = genres.get(genre);
        //System.out.println(genreID + " ***GENRE ID***");
        Intent i = new Intent(this, MovieListActivity.class);
        i.putExtra(MovieListActivity.EXTRA_MESSAGE, genreID);
        i.putExtra(MovieListActivity.EXTRA_EMAIL, email);
        startActivity(i);
    }

    public void onSearch(View v){
        TextView textView = (TextView)findViewById(R.id.search);
        String smovie = textView.getText().toString();
        smovie = smovie.replace(" ", "%20");
        Intent i = new Intent(this, SearchActivity.class);
        i.putExtra(SearchActivity.EXTRA_MESSAGE, smovie);
        i.putExtra(SearchActivity.EXTRA_EMAIL, email);
        startActivity(i);
    }

    public void onWatchList(View v){
        Intent i = new Intent(this, MovieListActivity.class);
        i.putExtra(MovieListActivity.EXTRA_MESSAGE, "empty");
        i.putExtra(MovieListActivity.EXTRA_ACTION, "watchlist");
        i.putExtra(MovieListActivity.EXTRA_EMAIL, email);
        startActivity(i);
    }

    public void onWatchedList(View v){
        Intent i = new Intent(this, MovieListActivity.class);
        i.putExtra(MovieListActivity.EXTRA_MESSAGE, "empty");
        i.putExtra(MovieListActivity.EXTRA_ACTION, "watchedlist");
        i.putExtra(MovieListActivity.EXTRA_EMAIL, email);
        startActivity(i);
    }

}
