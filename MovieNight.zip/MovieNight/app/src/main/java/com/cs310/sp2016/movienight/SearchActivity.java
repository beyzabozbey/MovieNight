package com.cs310.sp2016.movienight;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class SearchActivity extends BaseActivity {
    public static final String EXTRA_MESSAGE = "message";
    public static final String EXTRA_EMAIL = "message2";
    ProgressDialog prgDialog;
    String email;
    //ArrayList<String> movieTitles = new ArrayList<String>();
    //ArrayList<String> descriptions = new ArrayList<String>();
    ArrayList<Movies> results = new ArrayList<Movies>();
    //ArrayList<Integer> imgids;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);
        Intent intent = getIntent();
        String smovie = intent.getStringExtra(EXTRA_MESSAGE); // initialize
        email = intent.getStringExtra(EXTRA_EMAIL);
        /*ConnectivityManager connMgr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        System.err.println("MovieListActivity started");
        if (networkInfo != null && networkInfo.isConnected()) {*/
        GetMovies tsk = new GetMovies();
        tsk.execute(smovie);
       /*     //new TMDBQueryManager().execute(query);
        } else {
            //TextView textView = new TextView(this);
            //textView.setText("No network connection.");
            //setContentView(textView);
        }*/


    }

    public void updateView(ArrayList<Movies> result) {
        final ListView list = (ListView)findViewById(R.id.listView);
        //Log.d("updateViewWithResults", result.toString());
        MovieListAdapter adapter = new MovieListAdapter(this, R.layout.row, result);//, imgids);
        list.setAdapter(adapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Movies Slecteditem = (Movies)list.getItemAtPosition(position);
                Toast.makeText(getApplicationContext(), Slecteditem.getName(), Toast.LENGTH_SHORT).show();
                Intent i = new Intent(SearchActivity.this, MoviePageActivity.class);
                Integer temp = Slecteditem.getId();
                i.putExtra(MoviePageActivity.EXTRA_MESSAGE, Slecteditem.getName());
                String abc = Slecteditem.getName();
                i.putExtra("movieid", temp.toString());
                String a = temp.toString();
                //System.out.println("debug " + temp.toString());
                i.putExtra("moviedesc", Slecteditem.getDescription());
                String b = Slecteditem.getDescription();
                i.putExtra("movieposter", Slecteditem.getPoster_path());
                String c = Slecteditem.getPoster_path();
                i.putExtra(MoviePageActivity.EXTRA_EMAIL, email);
                startActivity(i);

            }
        });

        // Add results to listView.
        /*ArrayAdapter<Movies> adapter
                = new ArrayAdapter<Movies>(this,
                android.R.layout.simple_list_item_1,
                result);
        listView.setAdapter(adapter);*/

        // Update Activity to show listView
        //setContentView(list);
    }

    class GetMovies extends AsyncTask<String, Void, ArrayList<Movies>> {

        private final String TMDB_API_KEY = "1257ae182d356824550544f60a1f8b10";

        @Override
        protected void onPreExecute(){
            prgDialog = new ProgressDialog(SearchActivity.this);
            prgDialog.setTitle("Loading");
            prgDialog.setMessage("Please wait...");
            prgDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            prgDialog.show();
        }

        @Override
        protected ArrayList<Movies> doInBackground(String... params){

            String genreID = params[0];
            try {
                return moviesByGenres(genreID);
            } catch (IOException e) {
                return null;
            }
        }

        /*@Override
        protected void onProgressUpdate(String... params){

        }*/

        @Override
        protected void onPostExecute(ArrayList<Movies> result){
            updateView(result);
            prgDialog.dismiss();
        }

        public ArrayList<Movies> moviesByGenres(String smovie) throws IOException {
            // Build URL
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("http://api.themoviedb.org/3/search/movie?query=" + smovie);
            stringBuilder.append("&api_key=" + TMDB_API_KEY);
            Log.i("url", stringBuilder.toString());
            //InputStream stream = null;
            try {
                URL url = new URL(stringBuilder.toString());
                // Establish a connection
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                //conn.setReadTimeout(10000 /* milliseconds */);
                //conn.setConnectTimeout(15000 /* milliseconds */);
                //conn.setRequestMethod("GET");
                //conn.addRequestProperty("Accept", "application/json"); // Required to get TMDB to play nicely.
                conn.setDoInput(true);
                conn.setRequestProperty("Content-Type", "application/JSON");
                //conn.connect();

                BufferedReader reader
                        = new BufferedReader(
                        new InputStreamReader(conn.getInputStream()));

                StringBuilder strBuilder = new StringBuilder();
                String line = "";
                while ((line = reader.readLine()) != null) {
                    strBuilder.append(line);
                }

                conn.disconnect();
                System.out.println(strBuilder.toString());
                return parseResult(strBuilder.toString());
                //int responseCode = conn.getResponseCode();
                //Log.d("TMDBQueryManager", "The response code is: " + responseCode + " " + conn.getResponseMessage());

                //stream = conn.getInputStream();
                //return parseResult(stringify(stream));
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            /*finally {
                if (stream != null) {
                    stream.close();
                }
            }*/
            return null;
        }
    }

    private ArrayList<Movies> parseResult(String result) {

        String streamAsString = result;

        try {
            JSONObject jsonObject = new JSONObject(streamAsString);
            JSONArray arr = (JSONArray) jsonObject.get("results");
            for (Integer i = 0; i < arr.length(); i++) {
                System.out.println("Json Parsing la la la " + i.toString());
                JSONObject jsonMovieObject = arr.getJSONObject(i);
                //System.out.println("Say hello 1");
                Movies movie = new Movies();
                //System.out.println("Say hello 2");
                movie.setId(Integer.parseInt(jsonMovieObject.getString("id")));
                //System.out.println("Say hello 3");
                movie.setName(jsonMovieObject.getString("title"));
                //System.out.println("Say hello 4");
                //movieTitles.add(movie.getName());
                //System.out.println("Say hello 5");
                movie.setDescription(jsonMovieObject.getString("overview"));
                System.out.println("Say hello 6");
                //descriptions.add(movie.getDescription());
                movie.setPoster_path(jsonMovieObject.getString("poster_path"));
                //System.out.println("Say hello 7");
                Log.i("Movie Title: ", movie.getName());
                //Log.i("Description: ", movie.getDescription());

                StringBuilder imageUrl = new StringBuilder();
                imageUrl.append("http://image.tmdb.org/t/p/w300/" + movie.getPoster_path());
                Bitmap bitmap = null;
                try{
                    InputStream is = new URL(imageUrl.toString()).openStream();
                    bitmap = BitmapFactory.decodeStream(is);
                }catch(Exception e){
                    e.printStackTrace();
                }
                movie.setBitmap(bitmap);
                results.add(movie);
                //System.out.println("Say hello");
            }
        } catch (JSONException e) {
            System.err.println(e);
            Log.d("TMDBQueryManager", "Error parsing JSON. String was: " + streamAsString);
        }
        return results;
    }

    /*public String stringify(InputStream stream) throws IOException, UnsupportedEncodingException {
        Reader reader = null;
        reader = new InputStreamReader(stream, "UTF-8");
        BufferedReader bufferedReader = new BufferedReader(reader);
        return bufferedReader.readLine();
    }*/
}
