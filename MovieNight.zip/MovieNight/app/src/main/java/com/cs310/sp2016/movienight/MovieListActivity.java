package com.cs310.sp2016.movienight;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.AsyncTask;
import android.os.Parcelable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.Reader;
import java.io.Serializable;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;

public class MovieListActivity extends BaseActivity {
    public static final String EXTRA_MESSAGE = "genre_id";
    public static final String EXTRA_EMAIL = "message";
    public static final String EXTRA_ACTION = "action";
    ProgressDialog prgDialog;
    String email;
    String action;
    //ArrayList<String> movieTitles = new ArrayList<String>();
    //ArrayList<String> descriptions = new ArrayList<String>();
    //ArrayList<Movies> results = new ArrayList<Movies>();
    //ArrayList<Integer> imgids;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_movie_list);
        Intent intent = getIntent();
        String genreId = intent.getStringExtra(EXTRA_MESSAGE); // initialize
        email = intent.getStringExtra(EXTRA_EMAIL);
        if(genreId.equals("empty")){
            action = intent.getStringExtra(EXTRA_ACTION);
            Task tsk = new Task();
            tsk.execute(action);
        }
        else {

            GetMovies tsk = new GetMovies();
            tsk.execute(genreId);
        }
        /*ConnectivityManager connMgr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();
        System.err.println("MovieListActivity started");
        if (networkInfo != null && networkInfo.isConnected()) {*/
       /*     //new TMDBQueryManager().execute(query);
        } else {
            //TextView textView = new TextView(this);
            //textView.setText("No network connection.");
            //setContentView(textView);
        }*/


    }

    public void updateView(ArrayList<Movies> result) {
        final ListView list = (ListView)findViewById(R.id.listView);
        //Log.d("updateViewWithResults", result.toString());
        MovieListAdapter adapter = new MovieListAdapter(this, R.layout.row, result);//, imgids);
        list.setAdapter(adapter);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Movies Slecteditem = (Movies)list.getItemAtPosition(position);
                Toast.makeText(getApplicationContext(), Slecteditem.getName(), Toast.LENGTH_SHORT).show();
                Intent i = new Intent(MovieListActivity.this, MoviePageActivity.class);
                System.out.println("dknkdnknkvndk bla bla ");
                Integer temp = Slecteditem.getId();
                i.putExtra(MoviePageActivity.EXTRA_MESSAGE, Slecteditem.getName());
                String abc = Slecteditem.getName();
                System.out.println("debug " + Slecteditem.getName());
                i.putExtra("movieid", temp.toString());
                String a = temp.toString();
                //System.out.println("debug " + temp.toString());
                i.putExtra("moviedesc", Slecteditem.getDescription());
                String b = Slecteditem.getDescription();
                System.out.println("debug " + Slecteditem.getDescription());
                i.putExtra("movieposter", Slecteditem.getPoster_path());
                String c = Slecteditem.getPoster_path();
                System.out.println("debug " + Slecteditem.getPoster_path());
               // i.putExtra("moviephoto", Slecteditem.getBitmap());
                System.out.println("beyxa beyza beyza  ");
                i.putExtra(MoviePageActivity.EXTRA_EMAIL, email);
                System.out.println("beyxa beyza beyza  2222");
                startActivity(i);

            }
        });
    }


    class GetMovies extends AsyncTask<String, Void, ArrayList<Movies>> {

        private final String TMDB_API_KEY = "1257ae182d356824550544f60a1f8b10";

        @Override
        protected void onPreExecute(){
            prgDialog = new ProgressDialog(MovieListActivity.this);
            prgDialog.setTitle("Loading");
            prgDialog.setMessage("Please wait...");
            prgDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            prgDialog.show();
        }

        @Override
        protected ArrayList<Movies> doInBackground(String... params){

            String genreID = params[0];
            try {
                return moviesByGenres(genreID);
            } catch (IOException e) {
                return null;
            }
        }

        /*@Override
        protected void onProgressUpdate(String... params){

        }*/

        @Override
        protected void onPostExecute(ArrayList<Movies> result){
            updateView(result);
            prgDialog.dismiss();
        }

        public ArrayList<Movies> moviesByGenres(String genreId) throws IOException {
            // Build URL
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("http://api.themoviedb.org/3/genre/" + genreId);
            stringBuilder.append("/movies?api_key=" + TMDB_API_KEY);
            Log.i("url", stringBuilder.toString());
            //InputStream stream = null;
            try {
                URL url = new URL(stringBuilder.toString());
                // Establish a connection
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                //conn.setReadTimeout(10000 /* milliseconds */);
                //conn.setConnectTimeout(15000 /* milliseconds */);
                //conn.setRequestMethod("GET");
                //conn.addRequestProperty("Accept", "application/json"); // Required to get TMDB to play nicely.
                conn.setDoInput(true);
                conn.setRequestProperty("Content-Type", "application/JSON");
                //conn.connect();

                BufferedReader reader
                        = new BufferedReader(
                        new InputStreamReader(conn.getInputStream()));

                StringBuilder strBuilder = new StringBuilder();
                String line = "";
                while ((line = reader.readLine()) != null) {
                    strBuilder.append(line);
                }

                conn.disconnect();
                System.out.println(strBuilder.toString());
                return parseResult(strBuilder.toString());
                //int responseCode = conn.getResponseCode();
                //Log.d("TMDBQueryManager", "The response code is: " + responseCode + " " + conn.getResponseMessage());

                //stream = conn.getInputStream();
                //return parseResult(stringify(stream));
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            /*finally {
                if (stream != null) {
                    stream.close();
                }
            }*/
            return null;
        }
    }

    private ArrayList<Movies> parseResult(String result) {

        String streamAsString = result;
        ArrayList<Movies> results = new ArrayList<Movies>();

        try {
            JSONObject jsonObject = new JSONObject(streamAsString);
            JSONArray arr = (JSONArray) jsonObject.get("results");
            for (Integer i = 0; i < arr.length(); i++) {
                System.out.println("Json Parsing la la la " + i.toString());
                JSONObject jsonMovieObject = arr.getJSONObject(i);
                //System.out.println("Say hello 1");
                Movies movie = new Movies();
                //System.out.println("Say hello 2");
                movie.setId(Integer.parseInt(jsonMovieObject.getString("id")));
                //System.out.println("Say hello 3");
                movie.setName(jsonMovieObject.getString("title"));
                //System.out.println("Say hello 4");
                //movieTitles.add(movie.getName());
                //System.out.println("Say hello 5");
                movie.setDescription(jsonMovieObject.getString("overview"));
                System.out.println("Say hello 6");
                //descriptions.add(movie.getDescription());
                movie.setPoster_path(jsonMovieObject.getString("poster_path"));
                //System.out.println("Say hello 7");
                Log.i("Movie Title: ", movie.getName());
                //Log.i("Description: ", movie.getDescription());

                StringBuilder imageUrl = new StringBuilder();
                imageUrl.append("http://image.tmdb.org/t/p/w300/" + movie.getPoster_path());
                Bitmap bitmap = null;
                try{
                    InputStream is = new URL(imageUrl.toString()).openStream();
                    bitmap = BitmapFactory.decodeStream(is);
                }catch(Exception e){
                    e.printStackTrace();
                }
                movie.setBitmap(bitmap);
                results.add(movie);
                //System.out.println("Say hello");
            }
        } catch (JSONException e) {
            System.err.println(e);
            Log.d("TMDBQueryManager", "Error parsing JSON. String was: " + streamAsString);
        }
        return results;
    }

    /*public String stringify(InputStream stream) throws IOException, UnsupportedEncodingException {
        Reader reader = null;
        reader = new InputStreamReader(stream, "UTF-8");
        BufferedReader bufferedReader = new BufferedReader(reader);
        return bufferedReader.readLine();
    }*/

    public class Task extends AsyncTask<String, Void, ArrayList<Movies>> {
        String maintype="";
        @Override
        protected void onPreExecute(){
            prgDialog = new ProgressDialog(MovieListActivity.this);
            prgDialog.setTitle("Loading");
            prgDialog.setMessage("Please wait...");
            prgDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
            prgDialog.show();
        }
        @Override
        protected ArrayList<Movies> doInBackground(String... params){
            String type = params[0];
            maintype = type;
            if(type.equals("watchlist")){
                return watchlist();
            }
            else {
                return watchedlist();
            }
        }
        @Override
        protected void onPostExecute(ArrayList<Movies> result){
            updateView(result);
            prgDialog.dismiss();
        }

        private ArrayList<Movies> watchlist() {
            String registerUrl = "http://192.168.1.48/MovieNight/watchlist.php";
            ArrayList<Movies> result = new ArrayList<Movies>();
            try {
                URL url = new URL(registerUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);
                connection.setDoInput(true);
                OutputStream outputStream = connection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("email", "UTF-8") + "=" + URLEncoder.encode(email, "UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();
                InputStream inputStream = connection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                String line = "";
                int i=0;
                String title="", desc="", ppath="", id="";
                while ((line = bufferedReader.readLine()) != null) {
                    if(i==0){
                        title = line;
                        i++;
                    }
                    else if(i==1){
                        desc = line;
                        i++;
                    }
                    else if(i==2){
                        id = line;
                        i++;
                    }
                    else {
                        ppath = line;
                        Movies movie = new Movies();
                        movie.setName(title);
                        movie.setPoster_path(ppath);
                        movie.setId(Integer.parseInt(id));
                        movie.setDescription(desc);
                        //set movie bitmap*****************
                        StringBuilder imageUrl = new StringBuilder();
                        imageUrl.append("http://image.tmdb.org/t/p/w300/" + movie.getPoster_path());
                        Bitmap bitmap = null;
                        try{
                            InputStream is = new URL(imageUrl.toString()).openStream();
                            bitmap = BitmapFactory.decodeStream(is);
                        }catch(Exception e){
                            e.printStackTrace();
                        }
                        movie.setBitmap(bitmap);
                        result.add(movie);
                        i=0;
                    }

                }
                bufferedReader.close();
                inputStream.close();
                connection.disconnect();
                return result;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
        private ArrayList<Movies> watchedlist(){
            String loginUrl = "http://192.168.1.48/MovieNight/watchedlist.php";
            ArrayList<Movies> result = new ArrayList<Movies>();
            try {
                URL url = new URL(loginUrl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("POST");
                connection.setDoOutput(true);
                connection.setDoInput(true);
                OutputStream outputStream = connection.getOutputStream();
                BufferedWriter bufferedWriter = new BufferedWriter(new OutputStreamWriter(outputStream, "UTF-8"));
                String post_data = URLEncoder.encode("email", "UTF-8") + "=" + URLEncoder.encode(email, "UTF-8");
                bufferedWriter.write(post_data);
                bufferedWriter.flush();
                bufferedWriter.close();
                outputStream.close();

                InputStream inputStream = connection.getInputStream();
                BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream, "iso-8859-1"));
                String line = "";
                int i=0;
                String title="", desc="", ppath="", id="";
                while ((line = bufferedReader.readLine()) != null) {
                    if(i==0){
                        title = line;
                        i++;
                    }
                    else if(i==1){
                        desc = line;
                        i++;
                    }
                    else if(i==2){
                        id = line;
                        i++;
                    }
                    else {
                        ppath = line;
                        Movies movie = new Movies();
                        movie.setName(title);
                        movie.setPoster_path(ppath);
                        movie.setId(Integer.parseInt(id));
                        movie.setDescription(desc);
                        //set movie bitmap*****************
                        StringBuilder imageUrl = new StringBuilder();
                        imageUrl.append("http://image.tmdb.org/t/p/w300/" + movie.getPoster_path());
                        Bitmap bitmap = null;
                        try{
                            InputStream is = new URL(imageUrl.toString()).openStream();
                            bitmap = BitmapFactory.decodeStream(is);
                        }catch(Exception e){
                            e.printStackTrace();
                        }
                        movie.setBitmap(bitmap);
                        result.add(movie);
                        i=0;
                    }
                }
                bufferedReader.close();
                inputStream.close();
                connection.disconnect();
                return result;
            } catch (MalformedURLException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }
            return null;
        }
    }

}
