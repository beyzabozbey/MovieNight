package com.cs310.sp2016.movienight;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.RatingBar;
import android.widget.TextView;

import java.io.IOException;
import java.io.InputStream;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

public class MovieListAdapter extends ArrayAdapter<Movies> {

    private final Activity context;
    private ArrayList<Movies> movieList;
    //private final ArrayList<String> movieTitles;
    //private final ArrayList<String> descriptions;
    //private final ArrayList<Integer> imgid;
    private int resource;
    //private LayoutInflater inflater = context.getLayoutInflater();

    public MovieListAdapter(Activity context, int resource, ArrayList<Movies> objects){//, ArrayList<Integer> imgid) {
        super(context, resource, objects);
        //super(context, R.layout.activity_movie_list_item);
        movieList=objects;
        this.resource=resource;
        this.context=context;
        //this.movieTitles=movieTitles;
        //this.descriptions=descriptions;
        //this.imgid=imgid;
    }

    public static Drawable LoadImage(String url, String mname) {
        try {
            InputStream is = (InputStream) new URL(url).getContent();
            Drawable d = Drawable.createFromStream(is, mname);
            return d;
        } catch (Exception e) {
            return null;
        }
    }

    public View getView(int position,View view,ViewGroup parent) {

        LayoutInflater inflater=context.getLayoutInflater();
        if(view == null){
            view = inflater.inflate(R.layout.row, null);
        }
        //View rowView=inflater.inflate(R.layout.activity_movie_list_item, null);
        Movies movie = new Movies();
        movie = movieList.get(position);
        TextView txtTitle = (TextView) view.findViewById(R.id.tvMovie);
        ImageView imageView = (ImageView) view.findViewById(R.id.icon);
        TextView extratxt = (TextView) view.findViewById(R.id.tvDesc);
        //RatingBar rbMovieRating = (RatingBar)view.findViewById(R.id.rbMovie);

        txtTitle.setText(movie.getName());
        //imageView.setImageResource(imgid.get(position));
        extratxt.setText(movie.getDescription());
        //StringBuilder url = new StringBuilder();
        //url.append("http://image.tmdb.org/t/p/original/" + movie.getPoster_path());
        //System.out.println(url.toString());
        //imageView.setImageDrawable(LoadImage(url.toString(), movie.getName()));
        /*try {
            Bitmap bitmap = BitmapFactory.decodeStream((InputStream) new URL(url.toString()).getContent());
            imageView.setImageBitmap(bitmap);
        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        Bitmap bitmap = null;
        try{
            InputStream is = new URL(url.toString()).openStream();
            bitmap = BitmapFactory.decodeStream(is);
        }catch(Exception e){
            e.printStackTrace();
        }*/
        imageView.setImageBitmap(movie.getBitmap());
        return view;

    };

    /*private final Activity context;
    private final String[] web;
    private final Integer[] imageId;
    public CustomList(Activity context,
                      String[] web, Integer[] imageId) {
        super(context, R.layout.activity_movie_list_item);
        this.context = context;
        this.web = web;
        this.imageId = imageId;

    }
    @Override
    public View getView(int position, View view, ViewGroup parent) {
        LayoutInflater inflater = context.getLayoutInflater();
        View rowView= inflater.inflate(R.layout.list_single, null, true);
        TextView txtTitle = (TextView) rowView.findViewById(R.id.txt);

        ImageView imageView = (ImageView) rowView.findViewById(R.id.img);
        txtTitle.setText(web[position]);

        imageView.setImageResource(imageId[position]);
        return rowView;
    }*/
}
